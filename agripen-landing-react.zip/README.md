AgriPen Landing Page (React + Vite + Tailwind)

This is a minimal starter React project for the AgriPen landing page.

How to run locally:

1. Extract the ZIP to a folder.
2. Open a terminal in the project folder.
3. Run:
   npm install
   npm run dev

Notes:
- This project uses Vite, React and Tailwind CSS.
- If you don't have Node.js installed, download from https://nodejs.org/
- After `npm run dev`, open the local address shown (usually http://localhost:5173)

You can customize src/App.jsx to edit text and content.
